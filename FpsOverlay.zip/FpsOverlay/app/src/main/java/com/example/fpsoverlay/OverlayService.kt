package com.example.fpsoverlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class OverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    companion object {
        const val ACTION_STOP = "com.example.fpsoverlay.STOP"
        private const val CHANNEL_ID = "overlay"
        private const val NOTIF_ID = 1
        val running = MutableStateFlow(false)
    }

    private val registry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val settingsState = mutableStateOf(OverlaySettings())
    private val scaleOverride = mutableStateOf<Float?>(null)

    private lateinit var repo: SettingsRepository
    private lateinit var collector: StatsCollector
    private var windowManager: WindowManager? = null
    private var view: ComposeView? = null
    private lateinit var params: WindowManager.LayoutParams

    // состояние перетаскивания
    private var startParamX = 0
    private var startParamY = 0
    private var startRawX = 0f
    private var startRawY = 0f
    private var needRebase = false

    override fun onCreate() {
        super.onCreate()
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED

        repo = SettingsRepository(this)
        collector = StatsCollector(this)
        settingsState.value = runBlocking { repo.flow.first() }

        createChannel()
        startForegroundCompat()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        showOverlay()
        running.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Оверлей FPS", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun startForegroundCompat() {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("FPS-оверлей работает")
            .setContentText("Нажмите, чтобы открыть настройки")
            .setContentIntent(open)
            .addAction(0, "Остановить", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notification, type)
    }

    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val s = settingsState.value
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = s.posX
            y = s.posY
        }

        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(this)
        cv.setViewTreeViewModelStoreOwner(this)
        cv.setViewTreeSavedStateRegistryOwner(this)
        cv.setContent {
            val st = collector.stats.collectAsState().value
            OverlayBadge(stats = st, s = settingsState.value, scaleOverride = scaleOverride.value)
        }

        val scaleDetector = ScaleGestureDetector(
            this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val cur = scaleOverride.value ?: settingsState.value.scale
                    scaleOverride.value = (cur * detector.scaleFactor).coerceIn(0.5f, 3f)
                    return true
                }

                override fun onScaleEnd(detector: ScaleGestureDetector) {
                    val v = scaleOverride.value ?: return
                    scope.launch { repo.update { it.copy(scale = v) } }
                }
            }
        )

        cv.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startParamX = params.x
                    startParamY = params.y
                    startRawX = ev.rawX
                    startRawY = ev.rawY
                    needRebase = false
                }
                MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> {
                    needRebase = true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (ev.pointerCount == 1 && !scaleDetector.isInProgress) {
                        if (needRebase) {
                            startParamX = params.x
                            startParamY = params.y
                            startRawX = ev.rawX
                            startRawY = ev.rawY
                            needRebase = false
                        } else {
                            params.x = (startParamX + (ev.rawX - startRawX)).toInt().coerceAtLeast(0)
                            params.y = (startParamY + (ev.rawY - startRawY)).toInt().coerceAtLeast(0)
                            try {
                                wm.updateViewLayout(cv, params)
                            } catch (e: Exception) {
                                // окно уже удалено
                            }
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    val x = params.x
                    val y = params.y
                    scope.launch { repo.update { it.copy(posX = x, posY = y) } }
                }
            }
            true
        }

        registry.currentState = Lifecycle.State.RESUMED
        wm.addView(cv, params)
        view = cv

        collector.start(scope) { settingsState.value }
        scope.launch {
            repo.flow.collect {
                settingsState.value = it
                scaleOverride.value = null
            }
        }
    }

    override fun onDestroy() {
        collector.stop()
        scope.cancel()
        view?.let {
            try {
                (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (e: Exception) {
                // ignore
            }
        }
        view = null
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
        running.value = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
