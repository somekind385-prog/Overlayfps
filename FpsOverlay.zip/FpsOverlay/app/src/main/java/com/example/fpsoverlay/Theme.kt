package com.example.fpsoverlay

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Lavender = Color(0xFFC9A7F0)
val Violet = Color(0xFF7B3FE4)
val Navy = Color(0xFF3A3F8F)
val Pink = Color(0xFFFF6FB5)

private val LightScheme = lightColorScheme(
    primary = Violet,
    onPrimary = Color.White,
    primaryContainer = Lavender,
    onPrimaryContainer = Navy,
    secondary = Pink,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFD6EA),
    onSecondaryContainer = Navy,
    background = Color(0xFFFBF7FF),
    onBackground = Color(0xFF22244D),
    surface = Color(0xFFFBF7FF),
    onSurface = Color(0xFF22244D),
    surfaceVariant = Color(0xFFEFE4FB),
    onSurfaceVariant = Navy,
)

private val DarkScheme = darkColorScheme(
    primary = Lavender,
    onPrimary = Color(0xFF2A1A52),
    primaryContainer = Violet,
    onPrimaryContainer = Color.White,
    secondary = Pink,
    onSecondary = Color(0xFF4A0A2C),
    secondaryContainer = Color(0xFF7A2A58),
    onSecondaryContainer = Color(0xFFFFD6EA),
    background = Color(0xFF14152B),
    onBackground = Color(0xFFEDE6FA),
    surface = Color(0xFF14152B),
    onSurface = Color(0xFFEDE6FA),
    surfaceVariant = Color(0xFF23265A),
    onSurfaceVariant = Color(0xFFD8CCF2),
)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
